﻿using System.ComponentModel.DataAnnotations;

namespace CaseStudy.Models
{
    public class Login
    {
        [Key]
        public string EmailId { get; set; }

        public string UserPassword { get; set; }
    }
}
