﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using CaseStudy.Models;

namespace CaseStudy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SignUpController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public SignUpController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        //api method to get data from userinfo table
        [HttpGet]
        public JsonResult Get()
        {
            //   these are raw queries we can use ef or stored procedures here
            string query = @"             
            select * from SignUp ";

            DataTable Table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("HotelDB");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    Table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(Table);
        }


        [HttpPost]
        public JsonResult Post(SignUp usin)
        {
            string query =
            @"insert into SignUp (UserName,Email,Password) 
                      values(
                      '" + usin.UserName + @"',
                      '" + usin.Email + @"',
                      '" + usin.Password + @"')
                       ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("HotelDB");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    /* myCommand.Parameters.AddWithValue*/
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Successfully");
        }
    }
}
