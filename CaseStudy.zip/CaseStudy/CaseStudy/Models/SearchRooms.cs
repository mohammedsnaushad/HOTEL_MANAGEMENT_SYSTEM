﻿namespace CaseStudy.Models
{
    public class SearchRooms
    {
        public string check_IN_DATE { get; set; }

        public string Check_OUT_DATE { get; set; }

        public int Rooms_Available { get; set; }

        public string RoomType { get; set; }
    }
}
